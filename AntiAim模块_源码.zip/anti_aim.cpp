#include "anti_aim.h"
#include "../../config/config.h"
#include "../../interfaces/CUserCmd/CUserCmd.h"

#include <algorithm>
#include <cmath>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

namespace AntiAim {

// ─── Constexpr ───────────────────────────────────────────────────────

constexpr float kDegToRad = static_cast<float>(M_PI) / 180.f;

// ─── Camera restoration bridge (read by hkOverrideView) ──────────────
bool  g_aa_active   = false;
float g_realPitch   = 0.f;
float g_realYaw     = 0.f;

// ─── Contamination tracking ──────────────────────────────────────────
static float s_lastRealPitch = 0.f;
static float s_lastRealYaw   = 0.f;
static float s_lastFakePitch = 0.f;
static float s_lastFakeYaw   = 0.f;
static bool  s_hadAA         = false;

// ═══════════════════════════════════════════════════════════════════════
//  OnCreateMove — single entry point (STATIC only)
// ═══════════════════════════════════════════════════════════════════════

void OnCreateMove(CUserCmd* cmd)
{
    if (!Config::anti_aim)
    {
        g_aa_active = false;
        s_hadAA     = false;
        return;
    }

    CBaseUserCmdPB* base = cmd->csgoUserCmd.pBaseCmd;
    if (!base || !base->pViewAngles)
        return;

    const bool fireTick = (cmd->nButtons.nValue & IN_ATTACK) != 0;

    // If both modes are OFF, nothing to do (except fireTick clean-up)
    if (Config::anti_aim_pitch_mode == Config::AA_PITCH_OFF
     && Config::anti_aim_yaw_mode   == Config::AA_YAW_OFF)
    {
        g_aa_active = false;
        s_hadAA     = false;
        return;
    }

    const float rawPitch = base->pViewAngles->angValue.x;
    const float rawYaw   = base->pViewAngles->angValue.y;

    // ══════════════════════════════════════════════════════════════════
    //  fireTick: do NOT touch cmd angles — aimbot already set the
    //  correct aim-point.  Do NOT update g_real (keep player's actual
    //  view from the previous frame).  Camera stays where the player
    //  is looking, not where the aimbot is aiming.
    //
    //  Tracking:  s_lastReal = g_real (player's actual view)
    //             s_lastFake = raw    (cmd angle = what entity becomes)
    //  This gives a non-zero delta so next frame's contamination
    //  detection can correctly undo the entity-angle → camera offset.
    // ══════════════════════════════════════════════════════════════════
    if (fireTick)
    {
        g_aa_active      = true;
        s_lastRealPitch  = g_realPitch;
        s_lastRealYaw    = g_realYaw;
        s_lastFakePitch  = rawPitch;
        s_lastFakeYaw    = rawYaw;
        s_hadAA          = true;
        return;
    }

    // ── Step 1: Determine real player angles ──────────────────────────
    float cleanPitch = rawPitch;
    float cleanYaw   = rawYaw;

    if (s_hadAA)
    {
        constexpr float kContamThreshold = 5.f;

        // Pitch: if raw ≈ lastFake → contaminated → compensate
        if (std::fabs(rawPitch - s_lastFakePitch) < kContamThreshold)
            cleanPitch = rawPitch - (s_lastFakePitch - s_lastRealPitch);

        // Yaw: if raw ≈ lastFake → contaminated → compensate
        float yawDiff = rawYaw - s_lastFakeYaw;
        while (yawDiff >  180.f) yawDiff -= 360.f;
        while (yawDiff < -180.f) yawDiff += 360.f;
        if (std::fabs(yawDiff) < kContamThreshold)
        {
            cleanYaw = rawYaw - (s_lastFakeYaw - s_lastRealYaw);
            while (cleanYaw >  180.f) cleanYaw -= 360.f;
            while (cleanYaw < -180.f) cleanYaw += 360.f;
        }
    }

    cleanPitch = std::clamp(cleanPitch, -89.f, 89.f);
    while (cleanYaw >  180.f) cleanYaw -= 360.f;
    while (cleanYaw < -180.f) cleanYaw += 360.f;

    g_realPitch = cleanPitch;
    g_realYaw   = cleanYaw;

    // ── Step 2: Compute fake angles (STATIC only) ─────────────────────

    float targetPitch = cleanPitch;
    float targetYaw   = cleanYaw;

    if (Config::anti_aim_pitch_mode != Config::AA_PITCH_OFF)
    {
        const float pv = std::clamp(Config::anti_aim_pitch_angle, 0.f, 89.f);
        targetPitch = -pv;
    }

    if (Config::anti_aim_yaw_mode != Config::AA_YAW_OFF)
    {
        targetYaw = cleanYaw + Config::anti_aim_yaw_angle;
    }

    // ══════════════════════════════════════════════════════════════════
    //  Step 3: Write fake angles to cmd (server body)
    // ══════════════════════════════════════════════════════════════════

    float& pitch = base->pViewAngles->angValue.x;
    float& yaw   = base->pViewAngles->angValue.y;

    pitch = targetPitch;
    yaw   = targetYaw;

    // Normalise
    pitch = std::clamp(pitch, -89.f, 89.f);
    while (yaw >  180.f) yaw -= 360.f;
    while (yaw < -180.f) yaw += 360.f;
    base->pViewAngles->angValue.z = 0.f;

    g_aa_active = true;

    // ── Save tracking for next frame ──────────────────────────────────
    s_lastRealPitch = cleanPitch;
    s_lastRealYaw   = cleanYaw;
    s_lastFakePitch = pitch;
    s_lastFakeYaw   = yaw;
    s_hadAA         = true;

    // ══════════════════════════════════════════════════════════════════
    //  Step 4: Movement correction (reverse rotation)
    // ══════════════════════════════════════════════════════════════════

    float yawDelta = yaw - cleanYaw;
    while (yawDelta >  180.f) yawDelta -= 360.f;
    while (yawDelta < -180.f) yawDelta += 360.f;
    if (std::fabs(yawDelta) > 0.01f)
    {
        const float rad = yawDelta * kDegToRad;
        const float sp  = std::sin(rad);
        const float cp  = std::cos(rad);
        // ── Reverse rotation: DO NOT MODIFY ───────────────────────────
        const float fm  = base->flForwardMove * cp + base->flSideMove * sp;
        const float sm  = base->flSideMove    * cp - base->flForwardMove * sp;

        base->flForwardMove = fm;
        base->flSideMove    = sm;
    }
}

} // namespace AntiAim
