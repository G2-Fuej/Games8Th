#pragma once

class CUserCmd;

namespace AntiAim {

// ── OnCreateMove: single AA entry point (Aspasia OnMove equivalent) ──
// 1. Captures PlayerAngles from cmd->viewangles at entry
// 2. Computes fake yaw/pitch based on config
// 3. Writes fake angles to cmd (server-only body orientation)
// 4. Performs reverse-rotation movement correction
// Camera restoration is handled separately in OverrideView (fov.cpp).
void OnCreateMove(CUserCmd* cmd);

// ─── Camera restoration bridge (read by hkOverrideView in fov.cpp) ───
// g_aa_active → true when AA wrote fake angles this tick
// g_realPitch / g_realYaw → PlayerAngles: player's real camera view
extern bool  g_aa_active;
extern float g_realPitch;
extern float g_realYaw;

} // namespace AntiAim
